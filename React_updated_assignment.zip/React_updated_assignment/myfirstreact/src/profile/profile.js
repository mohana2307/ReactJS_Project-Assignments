import React from 'react';
import axios from "axios"
import { useHistory } from "react-router-dom";
import "./profile.css"
import CustomizedDialogs from '../dialogue';
import map from '../mapimage.jpg'; 




class profile extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            error: null,
            isLoaded: false,
            items: [],
            showForm: false

        };
        this.uobj = this.props.location.state;
        // console.log("uobj" + this.uobj);
        this.Gotopost = this.Gotopost.bind(this);
        this.Gotogallery = this.Gotogallery.bind(this);
        this.Gotodo = this.Gotodo.bind(this);
        this.Gotohome = this.Gotohome.bind(this);
    }
    
Gotopost(e) {
        this.props.history.push("/post"); //move from one page to another using history in react router
    }

    Gotogallery(e) {
        this.props.history.push("/gallery");
    }

    Gotodo(e) {
        this.props.history.push("/todo");
    }
    Gotohome(e) {
        this.props.history.push("/");
    }

   
    render() {
        const iL = [this.uobj];

        return (

            <div class="ShadowMDiv">
                <div class="LeftMDiv">
                    <ul class="ListMDiv">
                        <li class="Active" onClick={this.Gotohome}><a href="javascript:void(0);">Profile</a></li>
                        <li onClick={this.Gotopost}><a href="javascript:void(0);">Post</a></li>
                        <li onClick={this.Gotogallery}><a href="javascript:void(0);">Gallery</a></li>
                        <li onClick={this.Gotodo}><a href="javascript:void(0);">ToDo</a></li>
                    </ul>
                </div>

                <div class="RightMDiv">

                    {
                        iL.map((item) => {

                            return (
                                <div class="TitleMDiv">
                                  <strong>Profile
                                      </strong>  


                                    <div class="ProfileMDiv">
                                        <div class="dropdown">
                                            <a class="dropbtn"><span class="ProfileMDiv"><img src={item.profilepicture} /></span>
                                              <span><CustomizedDialogs>  

                                                    <img src={item.profilepicture} style={{ width: 200, height: 200 }} />

                                                    <strong>
                                                        <div class="LineMDiv"><span></span>{item.name}</div>
                                                        <div class="LineMDiv"><span></span>{item.email} </div>


                                                    </strong>

                                                </CustomizedDialogs></span></a>


                                        </div>

                                    </div>
                                </div>
                            )
                        })}
                    {
                        iL.map((item) => {

                            return (



                                <div class="ProfileDetailMDiv">
                                    <div class="ProfileImageMDiv">
                                        <span class="ProfileMDiv"><img src={item.profilepicture} /></span>
                                    </div>
                                  
                                    <table>
                                        <tr>
                                            <th>

                                            <p style={{textAlign: 'left'}}>{item.name}</p>
                                    <ul style={{textAlign: 'left',}}>
                                    <div class="LineMDiv"><span>User name</span> :{item.username}</div>
                                    <div class="LineMDiv"><span>Email</span> : {item.email} </div>
                                    <div class="LineMDiv"><span>Phone</span> : {item.phone}</div>
                                    <div class="LineMDiv"><span>Website</span> : {item.website} </div>
                                    <div class="STitlMDiv">Company</div>
                                    <div class="LineMDiv"><span>Name</span> : {item.company.name}</div>
                                    <div class="LineMDiv"><span>Catchphrase</span> :  {item.company.catchPhrase}</div>
                                    <div class="LineMDiv"><span>Bs</span> : {item.company.bs}</div>
                                    
                                   </ul>
                                    </th>
                                  <th>

                                    <span style={{float:'right'}}>
                                    <div  class="STitlMDiv">Address</div>
                                    <div  class="LineMDiv"><span>Street</span> {item.address.street}</div>
                                    <div  class="LineMDiv"><span>Suite</span> : {item.address.suite}</div>
                                    <div class="LineMDiv"><span>City</span> : {item.address.city}</div>
                                    <div class="LineMDiv"><span>Zip code</span> : {item.address.zipcode}</div>
                                   

                <div class="MapMDiv">
                                        <img src={map} />
                                    </div>
                    </span> </th> </tr></table>







                                </div>)
                        })
                    }


                </div>




                





            </div>

        )
    }
}






export default profile;