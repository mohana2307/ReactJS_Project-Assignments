import logo from './logo.svg';
import './App.css';
import home from "../src/index/home"
import profile from '../src/profile/profile';
import { Route, HashRouter,Switch } from 'react-router-dom'
import post from '../src/post/post';
import gallery from '../src/gallery/gallery';
import todo from '../src/todo/todo';

function App() {
  return (
    // To navigate differenent component using routing
    //TO sync Hash part(#) in URL 
    <HashRouter>
    

    <div className="App">
    <Switch>

    
    <Route exact path="/" component={home}></Route>
     <Route path="/profile" component={profile}></Route>
     <Route path="/post" component={post}></Route>
     <Route path="/gallery" component={gallery}></Route>
     <Route path="/todo" component={todo}></Route>
     </Switch>
     
    </div> 
    </HashRouter>
  );
}

export default App;
