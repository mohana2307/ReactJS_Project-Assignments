import React from 'react'


class todo extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            error: null,
            isLoaded: false,
            items: []
        };
        this.uobj = this.props.location.state;
        console.log("uobj" + this.uobj);
        this.Gotopost = this.Gotopost.bind(this);
        this.Gotogallery = this.Gotogallery.bind(this);
        this.Gotodo = this.Gotodo.bind(this);
        this.Gotohome = this.Gotohome.bind(this);
        this.GotoSignout = this.GotoSignout.bind(this);
    }

    Gotopost(e) {
        this.props.history.push("/post");
    }

    Gotogallery(e) {
        this.props.history.push("/gallery");
    }

    Gotodo(e) {
        this.props.history.push("/todo");
    }
    Gotohome(e) {
        this.props.history.push("/");
    }
    GotoSignout(e) {
        this.props.history.push("/");
    }
    render(){
        return (

            <div class="ShadowMDiv">
                <div class="LeftMDiv">
                    <ul class="ListMDiv">

                        <li onClick={this.Gotohome}><a href="javascript:void(0);">Profile</a></li>
                        <li onClick={this.Gotopost}><a href="javascript:void(0);">Post</a></li>
                        <li onClick={this.Gotogallery}><a href="javascript:void(0);">Gallery</a></li>
                        <li onClick={this.Gotodo} class="Active"><a href="javascript:void(0);">ToDo</a></li>
                    </ul>
                </div>
                <div class="RightMDiv">
                    <div class="TitleMDiv">
                        ToDo


                        <div class="ProfileMDiv">
                            <div class="dropdown">
                                <a onClick={this.GotoSignout} href="javascript:void(0);" onclick="myFunction()" class="dropbtn"><span class="ProfileMDiv"><img src="https://panorbit.in/wp-content/uploads/2019/hotlink-ok/1001.jpeg" /></span>Sign Out</a>

                            </div>

                        </div>
                    </div>
                    <div class="ProfileDetailMDiv">
                        <div class="ProfileImageMDiv">
                            <strong>
                                ToDo coming soon....</strong>
                        </div>
                    </div>
                </div>
            </div>
    )
    }
    
}

export default todo;