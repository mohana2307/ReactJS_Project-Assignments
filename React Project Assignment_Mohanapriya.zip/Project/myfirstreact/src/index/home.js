
import React from 'react';
import axios from "axios"
import "./home.css"

//Here using class component 
class home extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        error: null,
        id:"",
        isLoaded: false,
        items: []
      };
      this.handleclick = this.handleclick.bind(this);

    }
//Its Life cycle hooks..will Immeditetly invoke component after first render cycle
  componentDidMount() {

    axios.get("https://panorbit.in/api/users.json")
    .then((response) => {
      const items = response.data.users;
      this.setState({
        isLoaded: true,
        items: items
      })
      
    });
  }

  handleclick(test, itemid) {    
    this.props.history.push({pathname:"/profile", state:itemid});
  }
//In react component to display any data (html) or jsx syntax by calling render
  render()
  {
    const iL = this.state.items;
    return(

      <div class="CenterMDiv">
      <div class="TitleMDiv">Select an account</div>
      <div class="SctrollMDiv">
      <ul class="ListMDiv">
        {
          iL.map(item =>{
            return <div>
              
              <li onClick={test => {this.handleclick(test, item)}} key={item}>
                <a href="javascript:void(0);"><span class="ProfileMDiv"><img src={item.profilepicture}/></span>{item.name}</a>
                </li>
              
              </div>
          })
        }
   </ul>    
</div>
</div>
    )
  }
  }
  
    

  


  export default home;